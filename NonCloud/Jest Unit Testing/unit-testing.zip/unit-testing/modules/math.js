function sum(a, b) {
    return a + b;
}

function diff(a, b) {
    return a - b;
}

function multiply(a, b) {
    return a * b;
}

module.exports = {
    sum,
    diff,
    multiply    
}