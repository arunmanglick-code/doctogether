const fs = require('fs');

function getFileCount(path) {
    
    return fs.readdirSync(path).length;
}

module.exports = {
    getFileCount
}