const {sum, diff, multiply} = require('../modules/math');

describe("Tests for my math module", () => {

  test('When given any two integers, return their sum', () => {
    expect(sum(1, 2)).toBe(3);
  });

  test('When given any two integers, return their difference', () => {
    expect(diff(1, 2)).toBe(-1);
  });

  test('When given any two integers, return their product', () => {
    expect(multiply(1, 2)).toBe(2);
  });
});


describe("Validation Matchers", () => {
  test('Common matchers', () => {         
    const value = sum(1,2);
    const myObject = {
      sum : sum(2,2),
      diff : diff(2,2)
    }

    //exact equality
    expect(value).toBe(3);

    //object equality
    expect(myObject).toEqual({sum : 4, diff : 0});
  });

  test('Matchers for numbers', () => {         
    const value = sum(1,2);        
    
    expect(value).toBe(3);
    expect(value).toEqual(3);  // here to equals and toBe are the same thing
    expect(value).toBeGreaterThan(2);
    expect(value).toBeGreaterThanOrEqual(2);
    expect(value).toBeLessThan(5);
    expect(value).toBeLessThanOrEqual(4);
  });

  test('Truthiness matchers', () => {                       
    const n = null;
    expect(n).toBeNull();
    expect(n).toBeDefined();
    expect(n).not.toBeUndefined();
    expect(n).not.toBeTruthy(); //matches anything that an if statement treats as true
    expect(n).toBeFalsy(); //matches anything that an if statement treats as false
  });

  function throwAnError() {
    throw new Error('junit is better');
  }

  test('Misc', () => {                       
    const arr = [
      'England',
      'Hungary',
      'Scotland',
      'Croatia'
    ]

    //for arrays
    expect(arr).toContain('England');

    //for exceptions
    expect(() => throwAnError()).toThrow(Error);

  });
})

xdescribe('Setup and tear downs', () => {    
  beforeEach(() => {
    setEnvironmentVariables();
    initConnectionToTestDatabase();
    jest.resetMocks();
  });
  
  afterEach(() => {
    closeConnectionToTestDatabase();
  }); 
  
  test("placeholder test to respect jest syntax", () => {

  });
});


beforeAll(() => console.log('1 - beforeAll'));
afterAll(() => console.log('1 - afterAll'));
beforeEach(() => console.log('1 - beforeEach'));
afterEach(() => console.log('1 - afterEach'));

describe('Scoped / Nested block', () => {
  beforeAll(() => console.log('2 - beforeAll'));
  afterAll(() => console.log('2 - afterAll'));
  beforeEach(() => console.log('2 - beforeEach'));
  afterEach(() => console.log('2 - afterEach'));
  test('', () => console.log('2 - test'));  
});




