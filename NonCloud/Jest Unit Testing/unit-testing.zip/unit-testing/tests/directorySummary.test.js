const directorySummary = require('../modules/directorySummary')
const fs = require('fs');
const path = require('path');

jest.mock('fs');

const files = {
    '/path/to/foo.txt' : 'Contents of foo.txt', 
    '/path/to/bar.txt' : 'Contents of bar.txt'
}

let mockFiles = Object.create(null);
function setMockFiles(newMockFiles) {
  mockFiles = Object.create(null);
  for (const file in newMockFiles) {
    const dir = path.dirname(file);    

    if (!mockFiles[dir]) {
      mockFiles[dir] = [];
    }    
    mockFiles[dir].push(path.basename(file));
  }  
}

fs.readdirSync.mockImplementation((path) => {
    return mockFiles[path] || [];
})

beforeAll(() => {
    setMockFiles(files);
})

describe("Test suite for directory summary module", () => {
    
    test("Given a path to a directory on the filesystem, return number of files in it", () => {
                        
        expect(directorySummary.getFileCount("/path/to")).toBe(2);
        expect(fs.readdirSync).toHaveBeenCalledTimes(1);        
    })
})