test("Mocking a function", () => {

    const myMock = jest.fn();

    myMock(10);
    myMock(20);

    console.log(JSON.stringify(myMock.mock));    
    expect(myMock.mock.calls.length).toBe(2);
    expect(myMock.mock.calls[0][0]).toBe(10);    
    expect(myMock.mock.calls[1][0]).toBe(20);
})

test.only("Mock Return values", () => {    
    const myMock = jest.fn();    
    myMock.mockReturnValueOnce(10).mockReturnValueOnce("TEN").mockReturnValue(true);
    
    expect(myMock()).toBe(10);
    expect(myMock()).toBe("TEN");    
    expect(myMock()).toBe(true);    

    console.log(JSON.stringify(myMock.mock));
})

test("Mocking a module", () => {
    const fs = require('fs');
    jest.mock('fs');

    const file = {
        text : "Lorem ipsum dolor sit amet"
    }

    fs.readFile.mockReturnValue(file);    
    expect(fs.readFile()).toEqual(file);  
});

test("Mock implementation", () => {
    const myMock = jest.fn();
    myMock.mockImplementation((a,b) => {
        return a + b;
    })

    myMock.mockImplementationOnce((a,b) => {
        return a - b;
    })

    myMock.mockImplementationOnce((a,b) => {
        return a * b;
    })
    
    expect(myMock(10,10)).toBe(0); 
    expect(myMock(10,10)).toBe(100);   
    expect(myMock(10,10)).toBe(20);        
});

test("mockResolvedValue", async () => {
    const myMock = jest.fn();
    
    //This is just syntactic sugar for mockImplementation(() => return Promise.resolve(value))
    myMock.mockResolvedValueOnce("FOO").mockResolvedValue("BAR");    

    expect(await myMock()).toBe("FOO");
    expect(await myMock()).toBe("BAR");
});

test("Mock Matchers", async () => {
    const myMock = jest.fn().mockReturnValue(10);
    
    expect(myMock(10)).toBe(10);
    expect(myMock(20)).toBe(10);    
    
    expect(myMock).toHaveBeenCalledTimes(2);
    
    //called atleast once
    expect(myMock).toHaveBeenCalledWith(10);

    //last call to the mock
    expect(myMock).toHaveBeenLastCalledWith(20);    
});